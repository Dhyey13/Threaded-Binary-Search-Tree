//
//  main.cpp
//  lab05
//
//  Created by Sean on 3/2/14.
//  Copyright (c) 2014 Sean. All rights reserved.
//

#include <string.h>
#include <iostream>
#include <iomanip>
#include <stdlib.h>
#include <fstream>
#include <cctype>
#include "tbst.h"
#include "NodeData.h"

using namespace std;

bool printToFile = false;

string* tokenInsertArr;
const char** filename;
const char* defaultFile[] = {"hamlet.txt"};
string stringInitializer = "";
int numFiles;
int numOfTokens = 0;
int printCount = 0;
int const printAmount = 21;
int const printAmountPerLineMax = 7;
ofstream fout;
bool ifFileArg = false;
bool noMoreFiles = false;

bool debug = false;
#define blank ' '
#define enter '\n'
#define tab '\t'


void printTokens(NodeData* nodeArray, int arraySize, bool isMostToLeast);
void bullshit(ifstream &inputFile, int targetIndex, tbst* tree);
void print(NodeData* node);

int main(int argc, const char * argv[])
{
    // /Users/Sean/Library/Developer/Xcode/DerivedData/lab05-fmgupeimbpbaghezxrbzljrabofd/Build/Products/Debug
    cout << "HI! This is the intro." << endl;
    numFiles = argc;
    
    if(numFiles > 1) {
    if (strcmp(argv[argc-1], "DEBUG") == 0) {
            debug = true;
            numFiles--;
        }
    else if (strcmp(argv[argc-1], "FILE") == 0) {
        printToFile = true;
        numFiles--;
    }
    }
    if(numFiles > 2)
    {
    if (strcmp(argv[argc-2], "FILE") == 0) {
        printToFile = true;
        numFiles--;
    }
    }
    
    filename = new const char*[numFiles];
    
    if(numFiles > 1)
    {
        for (int i = 1; i <= numFiles; i++) {
//            cout << *argv[i] << " " << argv[i];
            filename[i-1] = argv[i];
            ifFileArg = true;
        }
    }

    fout.open ("lab5out.txt");
    
    
//    ifstream* inputFile;
    
    for (int targetIndex=0; targetIndex < numFiles; targetIndex++) {
        
        
        tbst* tree = new tbst();
        if (ifFileArg)
        {
            ifstream inputFile((filename[targetIndex]));
            while (!inputFile && targetIndex < numFiles - 1)  {
//                noMoreFiles = false;
                cerr << (filename[targetIndex]) << " does not exist." << endl;
                targetIndex++;
                ifstream inputFile((filename[targetIndex]));
            }
            if (inputFile) {
                bullshit( inputFile, targetIndex, tree);
            }
        }
        else
        {
            ifstream inputFile(defaultFile[0]);
            bullshit( inputFile, targetIndex, tree);
        }

       
        delete tree;
    }
    
//    void (*printtest)(NodeData*) = &print;
//    tree->iterInOrderTraversal(printtest);
    
    
//    delete inputFile;
    

    return 0;
    
}


void bullshit(ifstream &inputFile, int targetIndex, tbst* tree)
{
    if (!inputFile && !ifFileArg) {
        cerr << "File does not exist." << endl;
    }

    
    if(!noMoreFiles) {
        char targetChar;
        targetChar = inputFile.get();
        while (isblank(targetChar) || isspace(targetChar)){
            targetChar = inputFile.get();
            if (debug)
                cout << "Removed preceding blank, tab or enter" << endl;
        }
        
        string insertStr;
        insertStr = insertStr + targetChar;
        while(!inputFile.eof()){
            targetChar = inputFile.get();
            if (isblank(targetChar) || isspace(targetChar) || inputFile.eof())
            {
                tree->insert(insertStr);
                if (debug)
                    cout << "Inserted token: " << insertStr << endl;
                insertStr = stringInitializer;
            }
            else if (isalpha(targetChar) || targetChar == '\'')
            {
                insertStr = insertStr + targetChar;
            }
            else
            {
                if (debug)
                    cout << "Inserted token: " << insertStr << endl;
                tree->insert(insertStr);
                insertStr = stringInitializer;
                insertStr = insertStr + targetChar;
                if (debug)
                    cout << "Inserted token: " << insertStr << endl;
                tree->insert(insertStr);
                insertStr = stringInitializer;
            }
        }
    }
    int arraySize = tree->getNumberOfNodes();
    NodeData* nodeArray = new NodeData[arraySize];
    tree->treeToArray(tree->getRootPtr(), nodeArray);
    
    printTokens(nodeArray, arraySize, true);
    cout << endl;
    delete [] nodeArray;
}

void printTokens(NodeData* nodeArray, int arraySize, bool isMostToLeast)
{
    
    int switchIndex = 0;
    int enterTracker = 0;
    NodeData temp; // *always* initialize variables
    
    for (int traversalIndex=1; traversalIndex < arraySize; ++traversalIndex) // use pre-increment to avoid unneccessary temporary object
    {
        temp.setData(nodeArray[traversalIndex].getFrequency(), nodeArray[traversalIndex].getToken());
        switchIndex = traversalIndex-1;
        if (isMostToLeast)
        {
            while((switchIndex >= 0) && ((nodeArray[switchIndex].getFrequency() < temp.getFrequency() ||
                                          ((nodeArray[switchIndex].getFrequency() == temp.getFrequency() && nodeArray[switchIndex].getToken() < temp.getToken() )))))
            {
                nodeArray[switchIndex+1] = nodeArray[switchIndex];
                switchIndex -= 1;
            }
        }
        else
        {
            while((switchIndex >= 0) && ((nodeArray[switchIndex].getFrequency() > temp.getFrequency() ||
                                          ((nodeArray[switchIndex].getFrequency() == temp.getFrequency() && nodeArray[switchIndex].getToken() > temp.getToken() )))))
            {
                nodeArray[switchIndex+1] = nodeArray[switchIndex];
                switchIndex -= 1;
            }
            
        }
        nodeArray[switchIndex+1] = temp;
    }
    
    if(arraySize > printAmount)
        arraySize = printAmount;
    
    for(int traversalIndex = 0; traversalIndex < arraySize; traversalIndex++) {
        if (nodeArray[traversalIndex].getFrequency() != 0)
        {
            if (printToFile)
                fout << "[" << nodeArray[traversalIndex].getToken() << ": " << nodeArray[traversalIndex].getFrequency() << "] ";
            else
                cout << "[" << nodeArray[traversalIndex].getToken() << ": " << nodeArray[traversalIndex].getFrequency() << "] ";
            enterTracker++;
            if (enterTracker % printAmountPerLineMax == 0)
            {
                cout << endl;
            }
        }
    }
    if (arraySize % 7 != 0 && arraySize < 21)
    {
        cout << endl;
    }
}

/**
 * formats the prints of the traversals, it will have a line break every
 * seven elements
 * @param printCount - the current element count
 */
void print(NodeData* node)
{
    if (printToFile)
        fout << "[" << node->getToken() << ": " << node->getFrequency() << "] ";
    else
        cout << "[" << node->getToken() << ": " << node->getFrequency() << "] ";
    printCount++;
    if (printCount % 7 == 0 && printCount != 0){
        cout << endl;
    }
}

// wrong:
// traversal, setitem, default constructor for NodeData


//list of shit to go

//Friday: get tbst search & traversals working
// Saturdsay: finish tbst node and nodedata
// sunday: implement main & test


//next week
//work on memory, deletes
