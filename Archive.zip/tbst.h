//
//  tbst.h
//  lab05
//
//  Created by Sean on 3/2/14.
//  Copyright (c) 2014 Sean. All rights reserved.
//

#ifndef TBST_H
#define TBST_H

#include <iostream>
#include "Node.h"


class tbst
{
    
private:
    int data;
    Node* rootPtr;
    int printCount;
    int nodeCount;
    
    void insertRight(Node* newNode,Node** current,Node** predecessor,Node** successor);
    void insertLeft(Node* newNode,Node** current,Node** predecessor,Node** successor);
    void stepRight(Node** current, Node** parent, Node** predecessor);
    void stepLeft(Node** current, Node** parent, Node** successor);
    bool isLeaf(Node* targetNode);
    bool hasRightChild(Node** targetNode);
    bool hasLeftChild(Node** targetNode);
    void threading(Node* targetNode, Node* predecessor, Node* successor);
    void recPreOrderTraversal(Node* subTree);
    void recPostOrderTraversal(Node* subTree);
    void recInOrderTraversal(Node* subTree);
    
public:
    
    tbst();
    tbst(tbst* other);
    ~tbst();
    void clear();
    

    Node* getRootPtr();
    bool isEmpty();
    bool insert(string target);
    
    bool remove(string target);
    bool remove(Node* target);
    void removeLeaf(Node** parent, Node** current);

    bool contains(Node* subTree);
    
    void recPreOrderTraversal();
    void recPostOrderTraversal();
    void recInOrderTraversal();
    void printNodes(Node** subTree);
    void iterInOrderTraversal(void (visit(NodeData*)));
    
    int getNumberOfNodes();
    
    void print(Node* node);

    void treeToArray(Node* subTree, NodeData* array);
    void treeToArray(Node* subTree, NodeData* array, int* arrayPosition);
    
};
#include "tbst.cpp"

#endif
