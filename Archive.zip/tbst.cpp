/**
 @file tbst.cpp
 Source file that contains functions that deals with the overall threaded
 binary search tree. It contains constructor that sets a Node to its root,
 and destructor. Contains recursive and iterative traversal functions and printing
 functions. Also contains insert and remove functions that deals with the Nodes in the
 tree.
 
 @author Sean Lai
 @author Sai Badey
 @section ASSIGNEMT Lab5
 @section DUE_DATE
 */

#include "tbst.h"
#include "NodeData.h"
#include "Node.h"
using namespace std;


/* default constructor
 * Creates a tbst root pointing at the parameter
 * @param root - the root Node
 */
tbst::tbst()
{
    rootPtr = NULL;
    printCount = 0;
    nodeCount = 0;
}


tbst::tbst(tbst* other)
{
    //    (*visit)(current->getItem());
    Node* current = other->getRootPtr();
    Node* previous = NULL;
    
    while(!current->getisLeftThread() && current->getLeftChildPtr() != NULL)
    {
        //insert
        this->insert(other->getRootPtr()->getItem()->getToken());
        cout << current->getItem()->getToken();
        current = current->getLeftChildPtr();
    }
    
    while(current != NULL)
    {
        //        cout << current->getItem()->getToken() << endl;
        
        previous = current;
        current = current->getRightChildPtr();
        
        if(previous->getRightChildPtr() != NULL && !previous->getisRightThread())
        {
            while(!current->getisLeftThread() && current->getLeftChildPtr() != NULL)
            {
                this->insert(other->getRootPtr()->getItem()->getToken());
                current = current->getLeftChildPtr();
            }
        }
    }

}

// Destructor
// removes the tree
tbst::~tbst(){
    clear();
}

/**
 * Returns whether or the tree is empty
 * @return bool
 */
bool tbst::isEmpty() {
    
    if(rootPtr == NULL)
    {
        return true;
    }
    return false;
    // Return true if root is NULL
}

Node* tbst::getRootPtr()
{
    return rootPtr;
}


void tbst::recPreOrderTraversal(){
    recPreOrderTraversal(rootPtr);
}

/**
 * Main recursive function for preorder. It will format with endline every time
 * it prints seven elements.
 * @param subTree - the tbst tree for traversal
 * @param printCount - count of elements
 */
//void tbst::recPreOrderTraversal(Node* subTree, void (*visit))
void tbst::recPreOrderTraversal(Node* subTree)
{
    //        *visit(subTree);
    if(subTree != NULL)
    {
        printNodes(&subTree);
        
        if(!subTree->getisLeftThread() && subTree->getLeftChildPtr() != NULL)
        {
            recPreOrderTraversal(subTree->getLeftChildPtr());
        }
        
        if(!subTree->getisRightThread() && subTree->getRightChildPtr() != NULL)
        {
            recPreOrderTraversal(subTree->getRightChildPtr());
        }
        
    }
}


void tbst::recPostOrderTraversal(){
    recPostOrderTraversal(rootPtr);
}
/**
 * Main recursive function for postorder. It will format with endline every time
 * it prints seven elements.
 * @param subTree - the tbst tree for traversal
 * @param printCount - count of elements
 */
void tbst::recPostOrderTraversal(Node* subTree)
{
    if(subTree != NULL)
    {
        if(!subTree->getisLeftThread() && subTree->getLeftChildPtr() != NULL)
        {
            recPreOrderTraversal(subTree->getLeftChildPtr());
        }
        
        if(!subTree->getisRightThread() && subTree->getRightChildPtr() != NULL)
        {
            recPreOrderTraversal(subTree->getRightChildPtr());
        }
        
        printNodes(&subTree);
    }
}

void tbst::recInOrderTraversal(){
    recInOrderTraversal(rootPtr);
}/**
 * Main recursive function for inorder. It will format with endline every time
 * it prints seven elements.
 * @param subTree - the tbst tree for traversal
 * @param printCount - count of elements
 */
void tbst::recInOrderTraversal(Node* subTree)
{
    if(subTree != NULL)
    {
        
        
        if(!subTree->getisLeftThread() && subTree->getLeftChildPtr() != NULL)
        {
            recPreOrderTraversal(subTree->getLeftChildPtr());
        }
        printNodes(&subTree);
        
        if(!subTree->getisRightThread() && subTree->getRightChildPtr() != NULL)
        {
            recPreOrderTraversal(subTree->getRightChildPtr());
        }
        
        
    }
}

/**
 * Main iterative function for inorder. It will format with endline every time
 * it prints seven elements.
 * @param subTree - the tbst tree for traversal
 */
void tbst::iterInOrderTraversal(void (visit(NodeData*)))
{
//    (*visit)(current->getItem());
    Node* current = rootPtr;
    Node* previous = NULL;
    
    while(!current->getisLeftThread() && current->getLeftChildPtr() != NULL)
    {
        current = current->getLeftChildPtr();
    }
    
    while(current != NULL)
    {
       (*visit)(current->getItem());
    
        previous = current;
        current = current->getRightChildPtr();
        
        if(previous->getRightChildPtr() != NULL && !previous->getisRightThread())
        {
            while(!current->getisLeftThread() && current->getLeftChildPtr() != NULL)
            {
                current = current->getLeftChildPtr();
            }
        }
    }
}

void tbst::printNodes(Node** subTree)
{
    Node* temp = *subTree;
    cout << temp->getItem()->getToken() << " ";
    if(temp->getLeftChildPtr() != NULL)
        cout << temp->getLeftChildPtr()->getItem()->getToken() << " ";
    else
        cout << "null ";
    if(temp->getRightChildPtr() != NULL)
        cout << temp->getRightChildPtr()->getItem()->getToken() << endl;
    else
        cout << "null" << endl;
}

// Get the number of nodes present in tbst
int tbst::getNumberOfNodes()
{
    return nodeCount;
    // return the number of nodes
}

/**
 * insert function for the tbst. adds a data to right place in the tree
 * @param subTree - tree to search
 * @data - data to insert
 */

void tbst::threading(Node* targetNode, Node* predecessor, Node* successor)
{
    targetNode->setRightChildPtr(successor);
    targetNode->setLeftChildPtr(predecessor);
    targetNode->setisRightThread(successor != NULL);
    targetNode->setisLeftThread(predecessor != NULL);
}

bool tbst::insert(string target)
{
    if (target == "")
    {
        return false;
    }
    
    NodeData* newNodeData = new NodeData(0, target);
    Node* newNode = new Node();
    newNode->setItem(newNodeData);
    
    //if insert at beginning
    if (this->isEmpty())
    {
        rootPtr = newNode;
        nodeCount++;
        rootPtr->getItem()->increaseFrequency();
        return true;
    }
    
    bool found = false;
    Node* current = rootPtr;
    Node* parent = rootPtr;
    Node* successor = NULL;
    Node* predecessor = NULL;
    
    while(!found)
    {
        //if less than & not found, greater than & not found, or found
        if( *newNodeData == *current->getItem())
        {
            current->getItem()->increaseFrequency();
            delete newNode;
            found = true;
        }
        else if ( *newNodeData < *current->getItem() &&
                 (current->getLeftChildPtr() == NULL || current->getisLeftThread()))
        {            insertLeft(newNode, &current, &predecessor, &successor);
            threading(newNode, predecessor, successor);
            found = true;
        }
        else if ( *newNodeData > *current->getItem() &&
                 (current->getRightChildPtr() == NULL || current->getisRightThread()))
        {
            insertRight(newNode, &current, &predecessor, &successor);
            threading(newNode, predecessor, successor);
            found = true;
        }
        
        else if ( *newNodeData < *current->getItem())
        {
            stepLeft(&current, &parent, &successor);
        }
        
        else if ( *newNodeData > *current->getItem())
        {
            stepRight(&current, &parent, &predecessor);
        }
    }
    return found;
}
void tbst::insertRight(Node* newNode,Node** current,Node** predecessor,Node** successor)
{
    Node * temp = *current;
    temp->setRightChildPtr(newNode);
    temp->setisRightThread(false);
    temp->getRightChildPtr()->getItem()->increaseFrequency();
    predecessor = current;
    nodeCount++;
}

void tbst::insertLeft(Node* newNode,Node** current,Node** predecessor,Node** successor)
{
    Node * temp = *current;
    temp->setLeftChildPtr(newNode);
    temp->setisLeftThread(false);
    temp->getLeftChildPtr()->getItem()->increaseFrequency();
    successor = current;
    nodeCount++;
}

void tbst::stepLeft(Node** current, Node** parent, Node** successor)
{
    *parent = *current;
    Node * temp = *current;
    *successor = *parent;
    *current = temp->getLeftChildPtr();
}

void tbst::stepRight(Node** current, Node** parent, Node** predecessor)
{
    *parent = *current;
    Node * temp = *current;
    *predecessor = *parent;
    *current = temp->getRightChildPtr();
}

/**
 * delete function for the tbst. Deletes a data from the tree
 * @subTree - tree to search
 * @param data - data to delete
 */
bool tbst::remove(string target)
{
    if (this->isEmpty())
    {
        cout << "tree is empty" << endl;
        return false;
    }
    else if (target == rootPtr->getItem()->getToken() &&
             (rootPtr->getLeftChildPtr() == NULL &&
              rootPtr->getRightChildPtr() == NULL))
    {
        cout << "deleting root" << endl;
        delete rootPtr; //check delete statement
        return true;
    }
    else
    {
        NodeData* newNodeData = new NodeData(0, target);
        Node* newNode = new Node();
        newNode->setItem(newNodeData);
        
        if(contains(newNode)){
            cout << "found new node!" << endl;
            return remove(newNode);
        }
        else{
            cout << "could not find in list";
            return false;
        }
        
    }
}

bool tbst::remove(Node* target)
{
    bool found = false;
    Node* current = rootPtr;
    Node* parent = NULL;
    Node* successor = NULL;
    Node* predecessor = NULL;
    
    while(!found)
    {
        cout << "entered wile loop" << endl;
        if( target->getItem() == current->getItem())
        {
//            cout << "target node to be removed found" << endl;
            
            //no children
//            cout << current->getisLeftThread();
            if(isLeaf(current))
            {
                removeLeaf(&parent, &current);
                found = true;
            }
            
            else if(hasLeftChild(&current) && hasRightChild(&current))
            {
                Node* switchNode = current->getRightChildPtr();
                Node* switchNodeParent = current;
                
                while(!switchNode->getisLeftThread()){
                    switchNodeParent = switchNode;
                    switchNode = switchNode->getLeftChildPtr();
                }
                
                //replace the current node
                current->setItem(switchNode->getItem());
                switchNodeParent->setLeftChildPtr(current);
                switchNodeParent->setisLeftThread(true);
                
                if(current == rootPtr){
                    rootPtr = switchNode;
                }
                remove( switchNode);
                
                
                //                bool looped = false;
                //                //create a variable, set false
                //                //set true inside loop
                //                while(!switchNode->getisLeftThread()){
                //                    cout << "while" << endl;
                //                    switchNodeParent = switchNode;
                //                    switchNode = switchNode->getLeftChildPtr();
                //                    looped = true;
                //                }
                //
                //                switchNode->setLeftChildPtr(current->getLeftChildPtr());
                //
                //                if(looped)
                //                {
                //                    switchNodeParent->setisLeftThread(true);
                //                }
                //
                //                //if current's left exists && current's left's right is threaded
                //                if(!current->getisLeftThread() && current->getLeftChildPtr()->getisRightThread())
                //                {
                //                    current->getLeftChildPtr()->setRightChildPtr(switchNode);
                //                }
                
                found = true;
            }

            
            //right child only
            else if ( !hasLeftChild(&current) && hasRightChild(&current))
            {
                Node* rightChild = current->getRightChildPtr();

                if(parent->getRightChildPtr() == current){
                    parent->setRightChildPtr(rightChild);
                }
                else
                {
                    parent->setLeftChildPtr(rightChild);
                }
                
                if(rightChild->getisLeftThread()
                   || rightChild->getLeftChildPtr() == NULL)
                {//has no left child
                    rightChild->setLeftChildPtr(current->getLeftChildPtr());
                    rightChild->setisLeftThread(current->getisLeftThread());
                }
               
                
                cout << parent->getisLeftThread() << " " << parent->getisRightThread();
                
                found = true;
            }
            //left child only
            else if (hasLeftChild(&current) && !hasRightChild(&current))
            {
                Node* leftChild = current->getLeftChildPtr();
                
                if(parent->getRightChildPtr() == current){
                    parent->setRightChildPtr(leftChild);
                }
                else
                {
                    parent->setLeftChildPtr(leftChild);
                }
                
                if(leftChild->getisRightThread() || leftChild->getRightChildPtr() == NULL)
                {//has no left child
                   leftChild->setRightChildPtr(current->getRightChildPtr());
                    leftChild->setisRightThread(current->getisRightThread());
                }

                cout << parent->getisLeftThread() << " " << parent->getisRightThread();
                found = true;
            }
        }
        
        else if ( target->getItem() > current->getItem())
        {
            cout << "I stepped left";
            stepLeft(&current, &parent, &successor);
        }
        
        else if ( target->getItem() < current->getItem())
        {
            cout << "I stepped right";
            stepRight(&current, &parent, &predecessor);
        }
    }
    cout << endl;
//    recPreOrderTraversal();
    return found;
}

void tbst::removeLeaf(Node** parent, Node** current)
{
    Node* tempParent = *parent;
    Node* tempCurrent = *current;
    if(tempParent->getRightChildPtr() == *current){
        //check null statement
        tempParent->setRightChildPtr(tempCurrent->getRightChildPtr());
        tempParent->setisRightThread(tempCurrent->getisRightThread());
        delete *current;
    }
    else
    {
        tempParent->setLeftChildPtr(tempCurrent->getLeftChildPtr());
        tempParent->setisLeftThread(tempCurrent->getisLeftThread());
        delete *current;
    }
}

/*
 void tbst::stepLeft(Node** current, Node** parent, Node** successor)
 {
 *parent = *current;
 Node * temp = *current;
 *successor = *parent;
 *current = temp->getLeftChildPtr();
 
 */

/**
 * clear function for the tbst. Deletes a all nodes and set current to root
 */
void tbst::clear()
{
    delete rootPtr;
    rootPtr = NULL;
}

/**
 * search function for the tbst. search a the tree for the target data
 * @param subTree - subtree to search the data
 * @data - target data for the search
 */
bool tbst::contains(Node* subTree)
{
    if (subTree == NULL) {
        return false;
    }
    Node* current = rootPtr;
    Node* previous = NULL;
    while(!current->getisLeftThread() && current->getLeftChildPtr() != NULL)
    {
        current = current->getLeftChildPtr();
    }
    
    while(current != NULL)
    {
        if(current->getItem() == subTree->getItem())
        {
            return true;
        }
        
        previous = current;
        current = current->getRightChildPtr();
        
        if(previous->getRightChildPtr() != NULL && !previous->getisRightThread())
        {
            while(!current->getisLeftThread() && current->getLeftChildPtr() != NULL)
            {
                current = current->getLeftChildPtr();
            }
        }
    }
    
    return false;
}

void tbst::treeToArray(Node* subTree, NodeData* array)
{
    int arrayPosition = 0;
    treeToArray(subTree, array, &arrayPosition);
}

void tbst::treeToArray(Node* subTree, NodeData* array, int* arrayPosition)
{
    if (subTree == NULL) {
        return;
    }
    
    array[*arrayPosition] = *subTree->getItem();
//    cout << "array stuff: " << array[*arrayPosition].getToken() << " " << array[*arrayPosition].getFrequency() << endl;
    (*arrayPosition)++;
    
    if(!subTree->getisLeftThread() && subTree->getLeftChildPtr() != NULL)
    {
        treeToArray(subTree->getLeftChildPtr(), array, arrayPosition);
    }
    
    if(!subTree->getisRightThread() && subTree->getRightChildPtr() != NULL)
    {
    treeToArray(subTree->getRightChildPtr(), array, arrayPosition);
    }
}

bool tbst::isLeaf(Node* targetNode)
{
    return (targetNode->getisLeftThread() || targetNode->getLeftChildPtr() == NULL)
    && (targetNode->getisRightThread() || targetNode->getRightChildPtr() == NULL);
}

bool tbst::hasLeftChild(Node** targetNode)
{
    Node* temp = *targetNode;
    return (!temp->getisLeftThread() && temp->getLeftChildPtr() != NULL);
}

bool tbst::hasRightChild(Node** targetNode)
{
    Node* temp = *targetNode;
    return (!temp->getisRightThread() && temp->getRightChildPtr() != NULL);
}

